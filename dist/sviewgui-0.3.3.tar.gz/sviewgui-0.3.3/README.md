# sview-gui

PyQt5 GUI for data visualisation of csv file or pandas' DataFrame.
This GUI is based on the matplotlib and you can visualize your csv file in various ways.
Here are the main features;

# Usage

This package has only one method: buildGUI(). 
This method takes zero or one arguments like bellow.

# About license
© 2019 Sojiro Fukuda All Rightss Reserved.
Free to modify and redistribute by your own responsibility.