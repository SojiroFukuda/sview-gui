# sview-gui

PyQt5 GUI for data visualisation of csv file or pandas' DataFrame.
This GUI is based on the matplotlib and you can visualize your csv file in various ways.
Here are the main features;

+ Scatter, line, density, histgram, and box plot for visualisation your csv
+ Detail setting for the marker size, line width, number of bins of histgram, color map (from cmocean)
+ Save figure as editable PDF
+ Source code of the graph you plotted are recorded in the log window


# Usage

This package has only one method: buildGUI(). 
This method takes zero or one argument.
You can use the file path of your csv file as an argument.
Also, you can use pandas' DataFrame object for the argument.

# About license
© 2019 Sojiro Fukuda All Rightss Reserved.
Free to modify and redistribute by your own responsibility.
